const express = require('express');
const router = express.Router();
const twilioService = require('../services/twilioService');
const { authenticateToken } = require('../middleware/auth');

// Generates WebRTC Voice Token for agent browser dialer
router.get('/token', authenticateToken, (req, res) => {
  const tokenData = twilioService.generateVoiceToken(req.user.id);
  res.json({ success: true, ...tokenData });
});

// TwiML Outbound Voice webhook invoked by Twilio when browser client dials
router.post('/voice-twiml', (req, res) => {
  const to = req.body.To || req.query.To;
  const publicBaseUrl = process.env.PUBLIC_URL || `${req.protocol}://${req.get('host')}`;
  const twiml = twilioService.generateOutboundTwiML(to, publicBaseUrl);
  res.type('text/xml');
  res.send(twiml);
});

// Twilio Call Status Callback
router.post('/call-status-callback', (req, res) => {
  console.log('Twilio Call Status Callback:', req.body);
  res.status(200).send('<Response></Response>');
});

// Twilio Recording Callback
router.post('/recording-callback', (req, res) => {
  console.log('Twilio Recording Callback:', req.body);
  res.status(200).send('<Response></Response>');
});

module.exports = router;
