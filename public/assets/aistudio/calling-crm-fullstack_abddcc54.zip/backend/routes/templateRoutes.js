const express = require('express');
const router = express.Router();
const templateController = require('../controllers/templateController');
const { authenticateToken } = require('../middleware/auth');
const { authorizeRoles } = require('../middleware/rbac');

router.use(authenticateToken);

router.get('/', templateController.getTemplates);
router.post('/', authorizeRoles('admin', 'manager'), templateController.createTemplate);

module.exports = router;
