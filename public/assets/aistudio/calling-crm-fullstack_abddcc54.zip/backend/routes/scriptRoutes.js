const express = require('express');
const router = express.Router();
const scriptController = require('../controllers/scriptController');
const { authenticateToken } = require('../middleware/auth');
const { authorizeRoles } = require('../middleware/rbac');

router.use(authenticateToken);

router.get('/', scriptController.getScripts);
router.post('/', authorizeRoles('admin'), scriptController.createScript);
router.put('/:id', authorizeRoles('admin'), scriptController.updateScript);

module.exports = router;
