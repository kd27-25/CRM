const express = require('express');
const router = express.Router();
const callController = require('../controllers/callController');
const { authenticateToken } = require('../middleware/auth');

router.use(authenticateToken);

router.get('/', callController.getCallLogs);
router.get('/export', callController.exportCallLogsCsv);
router.post('/initiate', callController.initiateCall);
router.post('/disposition', callController.saveDisposition);

module.exports = router;
