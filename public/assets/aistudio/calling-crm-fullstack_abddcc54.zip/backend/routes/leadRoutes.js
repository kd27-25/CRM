const express = require('express');
const router = express.Router();
const leadController = require('../controllers/leadController');
const leadAssignmentService = require('../services/leadAssignmentService');
const { authenticateToken } = require('../middleware/auth');
const { authorizeRoles } = require('../middleware/rbac');

router.use(authenticateToken);

router.get('/', leadController.getLeads);
router.get('/export', leadController.exportLeadsCsv);
router.get('/:id', leadController.getLeadById);
router.post('/', leadController.createLead);
router.put('/:id', leadController.updateLead);
router.post('/:id/notes', leadController.addLeadNote);
router.post('/bulk-import', authorizeRoles('admin', 'manager'), leadController.bulkImportLeads);

// Assignment routes
router.post('/auto-assign/round-robin', authorizeRoles('admin', 'manager'), async (req, res, next) => {
  try {
    const { leadIds } = req.body;
    const result = await leadAssignmentService.assignRoundRobin(leadIds);
    res.json({ success: true, assignments: result });
  } catch (err) {
    next(err);
  }
});

router.post('/auto-assign/workload', authorizeRoles('admin', 'manager'), async (req, res, next) => {
  try {
    const { leadIds } = req.body;
    const result = await leadAssignmentService.assignWorkloadBalanced(leadIds);
    res.json({ success: true, assignments: result });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
