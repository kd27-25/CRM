const express = require('express');
const router = express.Router();
const followUpController = require('../controllers/followUpController');
const { authenticateToken } = require('../middleware/auth');

router.use(authenticateToken);

router.get('/today', followUpController.getTodayFollowUps);
router.post('/', followUpController.createFollowUp);
router.put('/:id', followUpController.updateFollowUpStatus);

module.exports = router;
