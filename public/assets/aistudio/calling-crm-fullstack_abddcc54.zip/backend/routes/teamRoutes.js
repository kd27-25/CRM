const express = require('express');
const router = express.Router();
const teamController = require('../controllers/teamController');
const { authenticateToken } = require('../middleware/auth');
const { authorizeRoles } = require('../middleware/rbac');

router.use(authenticateToken);

router.get('/users', authorizeRoles('admin', 'manager'), teamController.getUsers);
router.post('/users', authorizeRoles('admin'), teamController.createUser);
router.put('/users/:id', authorizeRoles('admin', 'manager'), teamController.updateUserStatus);

module.exports = router;
