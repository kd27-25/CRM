const { query } = require('../config/db');

exports.getScripts = async (req, res, next) => {
  try {
    const result = await query('SELECT * FROM call_scripts WHERE is_active = TRUE ORDER BY title ASC');
    res.json({ success: true, scripts: result.rows });
  } catch (err) {
    next(err);
  }
};

exports.createScript = async (req, res, next) => {
  try {
    const { title, category, content } = req.body;
    if (!title || !content) {
      return res.status(400).json({ success: false, message: 'Title and content are required' });
    }

    const result = await query(
      'INSERT INTO call_scripts (title, category, content) VALUES ($1, $2, $3) RETURNING *',
      [title, category || 'Outbound Sales', content]
    );

    res.status(201).json({ success: true, script: result.rows[0] });
  } catch (err) {
    next(err);
  }
};

exports.updateScript = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { title, category, content, isActive } = req.body;

    const result = await query(
      `UPDATE call_scripts 
       SET title = COALESCE($1, title),
           category = COALESCE($2, category),
           content = COALESCE($3, content),
           is_active = COALESCE($4, is_active),
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $5
       RETURNING *`,
      [title, category, content, isActive, id]
    );

    res.json({ success: true, script: result.rows[0] });
  } catch (err) {
    next(err);
  }
};
