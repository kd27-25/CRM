const { query } = require('../config/db');

exports.getTemplates = async (req, res, next) => {
  try {
    const { channel } = req.query;
    let sql = 'SELECT * FROM templates WHERE is_active = TRUE';
    let params = [];
    if (channel) {
      sql += ' AND channel = $1';
      params.push(channel);
    }
    sql += ' ORDER BY title ASC';
    const result = await query(sql, params);
    res.json({ success: true, templates: result.rows });
  } catch (err) {
    next(err);
  }
};

exports.createTemplate = async (req, res, next) => {
  try {
    const { title, channel, subject, body } = req.body;
    if (!title || !channel || !body) {
      return res.status(400).json({ success: false, message: 'Title, channel, and body are required' });
    }

    const result = await query(
      `INSERT INTO templates (title, channel, subject, body, created_by)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [title, channel, subject || null, body, req.user.id]
    );

    res.status(201).json({ success: true, template: result.rows[0] });
  } catch (err) {
    next(err);
  }
};
