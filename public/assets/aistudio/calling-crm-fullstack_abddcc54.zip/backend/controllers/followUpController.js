const { query } = require('../config/db');

exports.getTodayFollowUps = async (req, res, next) => {
  try {
    let agentFilter = '';
    let values = [];

    if (req.user.role === 'agent') {
      agentFilter = 'AND f.user_id = $1';
      values.push(req.user.id);
    }

    // Scheduled for today (00:00:00 to 23:59:59) or pending/overdue from earlier
    const sql = `
      SELECT f.*, 
             l.first_name, l.last_name, l.phone, l.company, l.status as lead_status,
             u.name as agent_name
      FROM follow_ups f
      JOIN leads l ON l.id = f.lead_id
      JOIN users u ON u.id = f.user_id
      WHERE f.status IN ('pending', 'overdue')
      ${agentFilter}
      ORDER BY f.scheduled_at ASC
    `;

    const result = await query(sql, values);
    const now = new Date();

    const formatted = result.rows.map(item => {
      const scheduledDate = new Date(item.scheduled_at);
      const isOverdue = scheduledDate < now;
      return {
        ...item,
        isOverdue,
        computedStatus: isOverdue ? 'overdue' : 'pending',
      };
    });

    res.json({ success: true, followUps: formatted });
  } catch (err) {
    next(err);
  }
};

exports.createFollowUp = async (req, res, next) => {
  try {
    const { leadId, scheduledAt, notes, priority = 'medium' } = req.body;
    if (!leadId || !scheduledAt) {
      return res.status(400).json({ success: false, message: 'leadId and scheduledAt are required' });
    }

    const result = await query(
      `INSERT INTO follow_ups (lead_id, user_id, scheduled_at, status, notes, priority)
       VALUES ($1, $2, $3, 'pending', $4, $5)
       RETURNING *`,
      [leadId, req.user.id, new Date(scheduledAt).toISOString(), notes || null, priority]
    );

    res.status(201).json({ success: true, followUp: result.rows[0] });
  } catch (err) {
    next(err);
  }
};

exports.updateFollowUpStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status, notes } = req.body;

    const completedAt = status === 'completed' ? 'CURRENT_TIMESTAMP' : 'NULL';
    const result = await query(
      `UPDATE follow_ups 
       SET status = $1, notes = COALESCE($2, notes), completed_at = ${completedAt}
       WHERE id = $3
       RETURNING *`,
      [status, notes, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Follow-up not found' });
    }

    res.json({ success: true, followUp: result.rows[0] });
  } catch (err) {
    next(err);
  }
};
