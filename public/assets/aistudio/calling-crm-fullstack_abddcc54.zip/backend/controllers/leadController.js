const { query } = require('../config/db');
const { Parser } = require('json2csv');

exports.getLeads = async (req, res, next) => {
  try {
    const {
      status,
      source,
      assignedTo,
      search,
      sortBy = 'created_at',
      sortOrder = 'DESC',
      page = 1,
      limit = 25,
    } = req.query;

    let conditions = [];
    let values = [];
    let counter = 1;

    // RBAC: Agents can only view their assigned leads unless manager/admin
    if (req.user.role === 'agent') {
      conditions.push(`l.assigned_to = $${counter++}`);
      values.push(req.user.id);
    } else if (assignedTo) {
      conditions.push(`l.assigned_to = $${counter++}`);
      values.push(assignedTo);
    }

    if (status) {
      conditions.push(`l.status = $${counter++}`);
      values.push(status);
    }

    if (source) {
      conditions.push(`l.source = $${counter++}`);
      values.push(source);
    }

    if (search) {
      conditions.push(`(
        l.first_name ILIKE $${counter} OR
        l.last_name ILIKE $${counter} OR
        l.phone ILIKE $${counter} OR
        l.email ILIKE $${counter} OR
        l.company ILIKE $${counter}
      )`);
      values.push(`%${search}%`);
      counter++;
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
    const safeSortBy = ['created_at', 'first_name', 'last_name', 'company', 'status', 'updated_at'].includes(sortBy)
      ? `l.${sortBy}`
      : 'l.created_at';
    const safeOrder = sortOrder.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';

    const offset = (parseInt(page, 10) - 1) * parseInt(limit, 10);

    const countSql = `SELECT COUNT(*) FROM leads l ${whereClause}`;
    const totalCountRes = await query(countSql, values);
    const total = parseInt(totalCountRes.rows[0].count, 10);

    const dataSql = `
      SELECT 
        l.id, l.first_name, l.last_name, l.phone, l.email, l.company, 
        l.source, l.status, l.tags, l.assigned_to, l.notes, l.created_at, l.updated_at,
        u.name AS assigned_agent_name,
        (SELECT COUNT(*) FROM calls c WHERE c.lead_id = l.id) AS call_count,
        (SELECT MAX(started_at) FROM calls c WHERE c.lead_id = l.id) AS last_called_at
      FROM leads l
      LEFT JOIN users u ON u.id = l.assigned_to
      ${whereClause}
      ORDER BY ${safeSortBy} ${safeOrder}
      LIMIT $${counter++} OFFSET $${counter++}
    `;

    values.push(parseInt(limit, 10), offset);
    const dataRes = await query(dataSql, values);

    res.json({
      success: true,
      data: dataRes.rows,
      pagination: {
        page: parseInt(page, 10),
        limit: parseInt(limit, 10),
        total,
        totalPages: Math.ceil(total / parseInt(limit, 10)),
      },
    });
  } catch (err) {
    next(err);
  }
};

exports.getLeadById = async (req, res, next) => {
  try {
    const { id } = req.params;

    const leadRes = await query(
      `SELECT l.*, u.name as assigned_agent_name, u.email as assigned_agent_email
       FROM leads l
       LEFT JOIN users u ON u.id = l.assigned_to
       WHERE l.id = $1`,
      [id]
    );

    const lead = leadRes.rows[0];
    if (!lead) {
      return res.status(404).json({ success: false, message: 'Lead not found' });
    }

    if (req.user.role === 'agent' && lead.assigned_to !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Access denied: lead assigned to another agent' });
    }

    // Full timeline: Calls, Follow-ups, Notes, and Activity logs
    const callsRes = await query(
      `SELECT c.*, u.name as agent_name 
       FROM calls c 
       LEFT JOIN users u ON u.id = c.user_id 
       WHERE c.lead_id = $1 ORDER BY c.started_at DESC`,
      [id]
    );

    const followUpsRes = await query(
      `SELECT f.*, u.name as agent_name 
       FROM follow_ups f 
       LEFT JOIN users u ON u.id = f.user_id 
       WHERE f.lead_id = $1 ORDER BY f.scheduled_at ASC`,
      [id]
    );

    const notesRes = await query(
      `SELECT n.*, u.name as author_name 
       FROM lead_notes n 
       LEFT JOIN users u ON u.id = n.user_id 
       WHERE n.lead_id = $1 ORDER BY n.created_at DESC`,
      [id]
    );

    const activitiesRes = await query(
      `SELECT a.*, u.name as user_name 
       FROM activity_logs a 
       LEFT JOIN users u ON u.id = a.user_id 
       WHERE a.lead_id = $1 ORDER BY a.created_at DESC LIMIT 20`,
      [id]
    );

    res.json({
      success: true,
      lead,
      timeline: {
        calls: callsRes.rows,
        followUps: followUpsRes.rows,
        notes: notesRes.rows,
        activities: activitiesRes.rows,
      },
    });
  } catch (err) {
    next(err);
  }
};

exports.createLead = async (req, res, next) => {
  try {
    const { firstName, lastName, phone, email, company, source, status, tags, assignedTo, notes } = req.body;

    if (!firstName || !lastName || !phone) {
      return res.status(400).json({ success: false, message: 'First name, last name, and phone are required' });
    }

    // Clean phone number and check duplicates
    const cleanPhone = phone.replace(/[^0-9+]/g, '');
    const dupRes = await query('SELECT id, first_name, last_name FROM leads WHERE phone = $1', [cleanPhone]);
    if (dupRes.rows.length > 0) {
      return res.status(409).json({
        success: false,
        message: `Duplicate phone number! A lead already exists: ${dupRes.rows[0].first_name} ${dupRes.rows[0].last_name} (ID: ${dupRes.rows[0].id})`,
      });
    }

    const assignedAgentId = req.user.role === 'agent' ? req.user.id : (assignedTo || null);

    const insertSql = `
      INSERT INTO leads (first_name, last_name, phone, email, company, source, status, tags, assigned_to, notes)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      RETURNING *
    `;

    const result = await query(insertSql, [
      firstName.trim(),
      lastName.trim(),
      cleanPhone,
      email ? email.toLowerCase().trim() : null,
      company ? company.trim() : null,
      source || 'Website',
      status || 'New',
      tags || [],
      assignedAgentId,
      notes || null,
    ]);

    const createdLead = result.rows[0];

    // Log activity
    await query(
      'INSERT INTO activity_logs (user_id, lead_id, action, details) VALUES ($1, $2, $3, $4)',
      [req.user.id, createdLead.id, 'LEAD_CREATED', JSON.stringify({ name: `${firstName} ${lastName}`, phone })]
    );

    res.status(201).json({ success: true, lead: createdLead });
  } catch (err) {
    next(err);
  }
};

exports.updateLead = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { firstName, lastName, phone, email, company, source, status, tags, assignedTo, notes } = req.body;

    const leadRes = await query('SELECT * FROM leads WHERE id = $1', [id]);
    const lead = leadRes.rows[0];
    if (!lead) {
      return res.status(404).json({ success: false, message: 'Lead not found' });
    }

    if (req.user.role === 'agent' && lead.assigned_to !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Access denied: lead assigned to another agent' });
    }

    let cleanPhone = lead.phone;
    if (phone && phone !== lead.phone) {
      cleanPhone = phone.replace(/[^0-9+]/g, '');
      const dupRes = await query('SELECT id FROM leads WHERE phone = $1 AND id != $2', [cleanPhone, id]);
      if (dupRes.rows.length > 0) {
        return res.status(409).json({ success: false, message: 'Another lead with this phone number already exists' });
      }
    }

    const assigned = req.user.role === 'agent' ? lead.assigned_to : (assignedTo !== undefined ? assignedTo : lead.assigned_to);

    const updateSql = `
      UPDATE leads 
      SET first_name = $1, last_name = $2, phone = $3, email = $4, company = $5,
          source = $6, status = $7, tags = $8, assigned_to = $9, notes = $10, updated_at = CURRENT_TIMESTAMP
      WHERE id = $11
      RETURNING *
    `;

    const result = await query(updateSql, [
      firstName || lead.first_name,
      lastName || lead.last_name,
      cleanPhone,
      email !== undefined ? email : lead.email,
      company !== undefined ? company : lead.company,
      source || lead.source,
      status || lead.status,
      tags || lead.tags,
      assigned,
      notes !== undefined ? notes : lead.notes,
      id,
    ]);

    // Log update
    await query(
      'INSERT INTO activity_logs (user_id, lead_id, action, details) VALUES ($1, $2, $3, $4)',
      [req.user.id, id, 'LEAD_UPDATED', JSON.stringify({ status: status || lead.status })]
    );

    res.json({ success: true, lead: result.rows[0] });
  } catch (err) {
    next(err);
  }
};

exports.addLeadNote = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { content } = req.body;
    if (!content) {
      return res.status(400).json({ success: false, message: 'Note content is required' });
    }

    const result = await query(
      'INSERT INTO lead_notes (lead_id, user_id, content) VALUES ($1, $2, $3) RETURNING *',
      [id, req.user.id, content.trim()]
    );

    res.status(201).json({ success: true, note: result.rows[0] });
  } catch (err) {
    next(err);
  }
};

exports.bulkImportLeads = async (req, res, next) => {
  try {
    const { leads } = req.body; // Expects array of lead objects parsed from CSV
    if (!Array.isArray(leads) || leads.length === 0) {
      return res.status(400).json({ success: false, message: 'No leads provided in payload' });
    }

    let imported = 0;
    let skippedDuplicates = 0;
    const errors = [];

    for (const item of leads) {
      try {
        const phone = (item.phone || '').toString().replace(/[^0-9+]/g, '');
        if (!phone || !item.name) {
          errors.push(`Row skipped: missing name or phone (${item.name || 'unnamed'})`);
          continue;
        }

        // Duplicate check
        const dupRes = await query('SELECT id FROM leads WHERE phone = $1', [phone]);
        if (dupRes.rows.length > 0) {
          skippedDuplicates++;
          continue;
        }

        const names = item.name.trim().split(' ');
        const firstName = names[0];
        const lastName = names.slice(1).join(' ') || '.';

        await query(
          `INSERT INTO leads (first_name, last_name, phone, email, company, source, status, notes)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
          [
            firstName,
            lastName,
            phone,
            item.email || null,
            item.company || null,
            item.source || 'Bulk CSV Import',
            item.status || 'New',
            item.notes || null,
          ]
        );
        imported++;
      } catch (e) {
        errors.push(`Error on ${item.name}: ${e.message}`);
      }
    }

    res.json({
      success: true,
      imported,
      skippedDuplicates,
      errorsCount: errors.length,
      errors,
    });
  } catch (err) {
    next(err);
  }
};

exports.exportLeadsCsv = async (req, res, next) => {
  try {
    const leadsRes = await query(`
      SELECT l.id, l.first_name, l.last_name, l.phone, l.email, l.company, 
             l.source, l.status, u.name as assigned_agent, l.notes, l.created_at
      FROM leads l
      LEFT JOIN users u ON u.id = l.assigned_to
      ORDER BY l.created_at DESC
    `);

    const fields = ['id', 'first_name', 'last_name', 'phone', 'email', 'company', 'source', 'status', 'assigned_agent', 'notes', 'created_at'];
    const json2csvParser = new Parser({ fields });
    const csv = json2csvParser.parse(leadsRes.rows);

    res.header('Content-Type', 'text/csv');
    res.attachment('calling_crm_leads.csv');
    return res.send(csv);
  } catch (err) {
    next(err);
  }
};
