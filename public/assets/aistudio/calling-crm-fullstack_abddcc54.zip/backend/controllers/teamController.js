const bcrypt = require('bcryptjs');
const { query } = require('../config/db');

exports.getUsers = async (req, res, next) => {
  try {
    const usersRes = await query(`
      SELECT u.id, u.name, u.email, u.role, u.team_id, u.phone, u.status, u.created_at,
             t.name as team_name,
             (SELECT COUNT(*) FROM leads l WHERE l.assigned_to = u.id) as assigned_leads_count,
             (SELECT COUNT(*) FROM calls c WHERE c.user_id = u.id) as total_calls_count
      FROM users u
      LEFT JOIN teams t ON t.id = u.team_id
      ORDER BY u.role, u.name
    `);
    res.json({ success: true, users: usersRes.rows });
  } catch (err) {
    next(err);
  }
};

exports.createUser = async (req, res, next) => {
  try {
    const { name, email, password, role = 'agent', teamId, phone } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ success: false, message: 'Name, email, and password are required' });
    }

    const salt = await bcrypt.genSalt(10);
    const hash = await bcrypt.hash(password, salt);

    const result = await query(
      `INSERT INTO users (name, email, password_hash, role, team_id, phone, status)
       VALUES ($1, $2, $3, $4, $5, $6, 'active')
       RETURNING id, name, email, role, team_id, phone, status, created_at`,
      [name.trim(), email.toLowerCase().trim(), hash, role, teamId || null, phone || null]
    );

    res.status(201).json({ success: true, user: result.rows[0] });
  } catch (err) {
    next(err);
  }
};

exports.updateUserStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status, role, teamId } = req.body;

    const result = await query(
      `UPDATE users 
       SET status = COALESCE($1, status),
           role = COALESCE($2, role),
           team_id = COALESCE($3, team_id),
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $4
       RETURNING id, name, email, role, status`,
      [status, role, teamId, id]
    );

    res.json({ success: true, user: result.rows[0] });
  } catch (err) {
    next(err);
  }
};
