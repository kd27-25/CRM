const { query } = require('../config/db');

exports.getDashboardStats = async (req, res, next) => {
  try {
    const { range = 'today' } = req.query; // 'today', '7d', '30d', 'all'
    const role = req.user.role;
    const userId = req.user.id;

    let timeFilter = 'TRUE';
    if (range === 'today') {
      timeFilter = "c.started_at >= CURRENT_DATE";
    } else if (range === '7d') {
      timeFilter = "c.started_at >= CURRENT_DATE - INTERVAL '7 days'";
    } else if (range === '30d') {
      timeFilter = "c.started_at >= CURRENT_DATE - INTERVAL '30 days'";
    }

    if (role === 'agent') {
      // Agent-specific KPIs
      const callsTodayRes = await query(
        `SELECT COUNT(*) as calls_count, COALESCE(SUM(duration_seconds), 0) as total_talk_time
         FROM calls c
         WHERE c.user_id = $1 AND ${timeFilter}`,
        [userId]
      );

      const conversionsRes = await query(
        `SELECT COUNT(*) as conversions
         FROM calls c
         WHERE c.user_id = $1 AND c.outcome = 'Converted' AND ${timeFilter}`,
        [userId]
      );

      const followUpsDueRes = await query(
        `SELECT COUNT(*) as count 
         FROM follow_ups 
         WHERE user_id = $1 AND status IN ('pending', 'overdue') AND scheduled_at <= CURRENT_TIMESTAMP + INTERVAL '1 day'`,
        [userId]
      );

      const outcomesRes = await query(
        `SELECT outcome, COUNT(*) as count 
         FROM calls c
         WHERE c.user_id = $1 AND outcome IS NOT NULL AND ${timeFilter}
         GROUP BY outcome`,
        [userId]
      );

      return res.json({
        success: true,
        stats: {
          callsCount: parseInt(callsTodayRes.rows[0].calls_count, 10),
          totalTalkTimeSeconds: parseInt(callsTodayRes.rows[0].total_talk_time, 10),
          conversions: parseInt(conversionsRes.rows[0].conversions, 10),
          followUpsDue: parseInt(followUpsDueRes.rows[0].count, 10),
          outcomes: outcomesRes.rows,
        },
      });
    }

    // Manager and Admin Team KPIs
    const callsRes = await query(
      `SELECT COUNT(*) as total_calls, COALESCE(SUM(duration_seconds), 0) as total_talk_time
       FROM calls c
       WHERE ${timeFilter}`
    );

    const conversionRes = await query(
      `SELECT 
         COUNT(*) FILTER (WHERE outcome = 'Converted') as converted_calls,
         COUNT(*) as total_dispositioned
       FROM calls c
       WHERE outcome IS NOT NULL AND ${timeFilter}`
    );

    const totalCalls = parseInt(callsRes.rows[0].total_calls, 10);
    const convertedCalls = parseInt(conversionRes.rows[0].converted_calls, 10);
    const totalDispositioned = parseInt(conversionRes.rows[0].total_dispositioned, 10);
    const conversionRate = totalDispositioned > 0 ? ((convertedCalls / totalDispositioned) * 100).toFixed(1) : 0;

    // Leaderboard
    const leaderboardRes = await query(
      `SELECT u.id, u.name, u.email,
              COUNT(c.id) as calls_made,
              COALESCE(SUM(c.duration_seconds), 0) as talk_time_seconds,
              COUNT(c.id) FILTER (WHERE c.outcome = 'Converted') as conversions
       FROM users u
       LEFT JOIN calls c ON c.user_id = u.id AND ${timeFilter}
       WHERE u.role = 'agent' AND u.status = 'active'
       GROUP BY u.id, u.name, u.email
       ORDER BY conversions DESC, calls_made DESC`
    );

    // Call Outcomes Breakdown
    const outcomesRes = await query(
      `SELECT outcome, COUNT(*) as count 
       FROM calls c
       WHERE outcome IS NOT NULL AND ${timeFilter}
       GROUP BY outcome`
    );

    // Lead Source Performance
    const sourceRes = await query(
      `SELECT l.source, COUNT(l.id) as lead_count,
              COUNT(l.id) FILTER (WHERE l.status = 'Converted') as converted_count
       FROM leads l
       GROUP BY l.source
       ORDER BY lead_count DESC`
    );

    res.json({
      success: true,
      stats: {
        totalCalls,
        totalTalkTimeSeconds: parseInt(callsRes.rows[0].total_talk_time, 10),
        conversionRate,
        convertedCalls,
        leaderboard: leaderboardRes.rows,
        outcomes: outcomesRes.rows,
        sources: sourceRes.rows,
      },
    });
  } catch (err) {
    next(err);
  }
};
