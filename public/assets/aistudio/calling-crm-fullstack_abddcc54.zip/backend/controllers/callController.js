const { query } = require('../config/db');
const { Parser } = require('json2csv');

exports.initiateCall = async (req, res, next) => {
  try {
    const { leadId, direction = 'outbound' } = req.body;
    if (!leadId) {
      return res.status(400).json({ success: false, message: 'leadId is required' });
    }

    const leadRes = await query('SELECT * FROM leads WHERE id = $1', [leadId]);
    const lead = leadRes.rows[0];
    if (!lead) {
      return res.status(404).json({ success: false, message: 'Lead not found' });
    }

    // Create call record with status in-progress
    const callInsert = await query(
      `INSERT INTO calls (lead_id, user_id, direction, status, started_at)
       VALUES ($1, $2, $3, 'in-progress', CURRENT_TIMESTAMP)
       RETURNING *`,
      [leadId, req.user.id, direction]
    );

    const call = callInsert.rows[0];

    // Log activity
    await query(
      'INSERT INTO activity_logs (user_id, lead_id, action, details) VALUES ($1, $2, $3, $4)',
      [req.user.id, leadId, 'CALL_INITIATED', JSON.stringify({ callId: call.id, phone: lead.phone })]
    );

    res.status(201).json({
      success: true,
      call,
      lead,
    });
  } catch (err) {
    next(err);
  }
};

/**
 * Mandatory Call Disposition endpoint
 * Logs call outcome, duration, notes, and optionally schedules a follow-up callback
 */
exports.saveDisposition = async (req, res, next) => {
  try {
    const { callId, outcome, notes, durationSeconds, nextFollowUpDate, nextFollowUpTime, followUpNotes } = req.body;

    if (!callId || !outcome) {
      return res.status(400).json({ success: false, message: 'callId and outcome are mandatory' });
    }

    const callRes = await query('SELECT * FROM calls WHERE id = $1', [callId]);
    const call = callRes.rows[0];
    if (!call) {
      return res.status(404).json({ success: false, message: 'Call not found' });
    }

    // Auto-update call status & duration
    const updateCallSql = `
      UPDATE calls
      SET outcome = $1, notes = $2, duration_seconds = $3, status = 'completed', ended_at = CURRENT_TIMESTAMP
      WHERE id = $4
      RETURNING *
    `;
    const updatedCall = await query(updateCallSql, [outcome, notes || null, durationSeconds || 0, callId]);

    // Update lead status based on disposition outcome
    let newLeadStatus = null;
    if (outcome === 'Interested') newLeadStatus = 'Interested';
    else if (outcome === 'Follow-up') newLeadStatus = 'Follow-up';
    else if (outcome === 'Converted') newLeadStatus = 'Converted';
    else if (outcome === 'Not Interested') newLeadStatus = 'Not Interested';
    else if (outcome === 'Wrong Number') newLeadStatus = 'Wrong Number';
    else newLeadStatus = 'Contacted';

    await query(
      'UPDATE leads SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
      [newLeadStatus, call.lead_id]
    );

    // If next follow-up was provided, schedule it automatically
    let createdFollowUp = null;
    if (nextFollowUpDate && nextFollowUpTime) {
      const scheduledDateTime = new Date(`${nextFollowUpDate}T${nextFollowUpTime}:00`);
      const followUpRes = await query(
        `INSERT INTO follow_ups (lead_id, user_id, scheduled_at, status, notes)
         VALUES ($1, $2, $3, 'pending', $4)
         RETURNING *`,
        [call.lead_id, req.user.id, scheduledDateTime.toISOString(), followUpNotes || notes || 'Call follow-up']
      );
      createdFollowUp = followUpRes.rows[0];
    }

    // Activity log
    await query(
      'INSERT INTO activity_logs (user_id, lead_id, action, details) VALUES ($1, $2, $3, $4)',
      [req.user.id, call.lead_id, 'CALL_DISPOSITION_LOGGED', JSON.stringify({ outcome, durationSeconds })]
    );

    res.json({
      success: true,
      call: updatedCall.rows[0],
      newLeadStatus,
      followUp: createdFollowUp,
    });
  } catch (err) {
    next(err);
  }
};

exports.getCallLogs = async (req, res, next) => {
  try {
    const { page = 1, limit = 25, outcome, agentId } = req.query;
    let conditions = [];
    let values = [];
    let counter = 1;

    if (req.user.role === 'agent') {
      conditions.push(`c.user_id = $${counter++}`);
      values.push(req.user.id);
    } else if (agentId) {
      conditions.push(`c.user_id = $${counter++}`);
      values.push(agentId);
    }

    if (outcome) {
      conditions.push(`c.outcome = $${counter++}`);
      values.push(outcome);
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
    const offset = (parseInt(page, 10) - 1) * parseInt(limit, 10);

    const callsSql = `
      SELECT c.*, 
             l.first_name, l.last_name, l.phone, l.company,
             u.name as agent_name
      FROM calls c
      JOIN leads l ON l.id = c.lead_id
      JOIN users u ON u.id = c.user_id
      ${whereClause}
      ORDER BY c.started_at DESC
      LIMIT $${counter++} OFFSET $${counter++}
    `;

    values.push(parseInt(limit, 10), offset);
    const callsRes = await query(callsSql, values);

    res.json({
      success: true,
      calls: callsRes.rows,
    });
  } catch (err) {
    next(err);
  }
};

exports.exportCallLogsCsv = async (req, res, next) => {
  try {
    const callsRes = await query(`
      SELECT c.id, c.started_at, c.duration_seconds, c.status, c.outcome, c.notes,
             l.first_name, l.last_name, l.phone, l.company,
             u.name as agent_name, c.recording_url
      FROM calls c
      JOIN leads l ON l.id = c.lead_id
      JOIN users u ON u.id = c.user_id
      ORDER BY c.started_at DESC
    `);

    const fields = ['id', 'started_at', 'duration_seconds', 'outcome', 'status', 'first_name', 'last_name', 'phone', 'company', 'agent_name', 'notes', 'recording_url'];
    const json2csvParser = new Parser({ fields });
    const csv = json2csvParser.parse(callsRes.rows);

    res.header('Content-Type', 'text/csv');
    res.attachment('calling_crm_call_logs.csv');
    return res.send(csv);
  } catch (err) {
    next(err);
  }
};
