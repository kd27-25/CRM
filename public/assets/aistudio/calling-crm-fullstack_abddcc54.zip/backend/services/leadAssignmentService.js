const { query } = require('../config/db');

/**
 * Lead Assignment Service
 * Supports:
 * 1. Round-Robin distribution across active agents
 * 2. Workload-Based distribution (assigns to agent with fewest active leads)
 */
class LeadAssignmentService {
  /**
   * Auto-assign leads using Round Robin
   * @param {Array<number>} leadIds 
   * @returns {Promise<Array<object>>}
   */
  async assignRoundRobin(leadIds) {
    const agentsRes = await query(
      "SELECT id, name FROM users WHERE role = 'agent' AND status = 'active' ORDER BY id ASC"
    );
    const agents = agentsRes.rows;

    if (!agents.length) {
      throw new Error('No active agents available for round-robin assignment');
    }

    const assignments = [];
    for (let i = 0; i < leadIds.length; i++) {
      const leadId = leadIds[i];
      const agent = agents[i % agents.length];

      await query(
        'UPDATE leads SET assigned_to = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
        [agent.id, leadId]
      );

      await query(
        'INSERT INTO activity_logs (user_id, lead_id, action, details) VALUES ($1, $2, $3, $4)',
        [agent.id, leadId, 'LEAD_ASSIGNED_ROUND_ROBIN', JSON.stringify({ assignedTo: agent.name })]
      );

      assignments.push({ leadId, assignedTo: agent });
    }

    return assignments;
  }

  /**
   * Auto-assign leads using Workload Balancing
   * Assigns incoming leads to the agent currently handling the fewest active leads
   * @param {Array<number>} leadIds 
   * @returns {Promise<Array<object>>}
   */
  async assignWorkloadBalanced(leadIds) {
    const agentsRes = await query(`
      SELECT u.id, u.name, COUNT(l.id) AS active_lead_count
      FROM users u
      LEFT JOIN leads l ON l.assigned_to = u.id AND l.status NOT IN ('Converted', 'Not Interested', 'Wrong Number')
      WHERE u.role = 'agent' AND u.status = 'active'
      GROUP BY u.id, u.name
      ORDER BY active_lead_count ASC, u.id ASC
    `);

    const agentWorkloads = agentsRes.rows.map(a => ({
      id: a.id,
      name: a.name,
      count: parseInt(a.active_lead_count, 10),
    }));

    if (!agentWorkloads.length) {
      throw new Error('No active agents available for workload assignment');
    }

    const assignments = [];
    for (const leadId of leadIds) {
      // Pick agent with minimum count
      agentWorkloads.sort((a, b) => a.count - b.count);
      const targetAgent = agentWorkloads[0];

      await query(
        'UPDATE leads SET assigned_to = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
        [targetAgent.id, leadId]
      );

      await query(
        'INSERT INTO activity_logs (user_id, lead_id, action, details) VALUES ($1, $2, $3, $4)',
        [targetAgent.id, leadId, 'LEAD_ASSIGNED_WORKLOAD', JSON.stringify({ assignedTo: targetAgent.name })]
      );

      targetAgent.count += 1;
      assignments.push({ leadId, assignedTo: targetAgent });
    }

    return assignments;
  }
}

module.exports = new LeadAssignmentService();
