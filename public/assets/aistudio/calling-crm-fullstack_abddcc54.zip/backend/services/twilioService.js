const twilio = require('twilio');

/**
 * Twilio Voice API Service
 * Handles:
 * 1. WebRTC Browser Client Access Tokens (Twilio Voice SDK)
 * 2. TwiML Voice Webhook (Dialing outbound phone numbers with recording enabled)
 * 3. Call Status & Recording Callback processing
 */
class TwilioService {
  constructor() {
    this.accountSid = process.env.TWILIO_ACCOUNT_SID;
    this.authToken = process.env.TWILIO_AUTH_TOKEN;
    this.apiKeySid = process.env.TWILIO_API_KEY_SID;
    this.apiKeySecret = process.env.TWILIO_API_KEY_SECRET;
    this.twimlAppSid = process.env.TWILIO_TWIML_APP_SID;
    this.callerId = process.env.TWILIO_CALLER_ID || '+18005550199';
  }

  isConfigured() {
    return Boolean(
      this.accountSid &&
      this.accountSid.startsWith('AC') &&
      this.apiKeySid &&
      this.apiKeySecret &&
      this.twimlAppSid
    );
  }

  /**
   * Generates a Twilio Voice Capability / Access Token for browser WebRTC
   * @param {string} identity - Unique agent identity (e.g. user ID or email)
   * @returns {string} JWT Token for @twilio/voice-sdk
   */
  generateVoiceToken(identity) {
    if (!this.isConfigured()) {
      // In development or demo mode when credentials aren't set yet, return simulated token
      return {
        token: `mock_twilio_token_${identity}_${Date.now()}`,
        identity,
        isMock: true,
        callerId: this.callerId,
      };
    }

    const AccessToken = twilio.jwt.AccessToken;
    const VoiceGrant = AccessToken.VoiceGrant;

    const voiceGrant = new VoiceGrant({
      outgoingApplicationSid: this.twimlAppSid,
      incomingAllow: true, // Allows receiving calls in browser
    });

    const token = new AccessToken(
      this.accountSid,
      this.apiKeySid,
      this.apiKeySecret,
      { identity: String(identity), ttl: 3600 }
    );

    token.addGrant(voiceGrant);
    return {
      token: token.toJwt(),
      identity,
      isMock: false,
      callerId: this.callerId,
    };
  }

  /**
   * Generates TwiML response for outbound call from WebRTC client
   * @param {string} to - Destination phone number
   * @param {string} publicBaseUrl - Callback domain for call events
   * @returns {string} XML string
   */
  generateOutboundTwiML(to, publicBaseUrl) {
    const VoiceResponse = twilio.twiml.VoiceResponse;
    const response = new VoiceResponse();

    if (to) {
      const dial = response.dial({
        callerId: this.callerId,
        record: 'record-from-answer-dual', // Records both sides of call
        recordingStatusCallback: `${publicBaseUrl}/api/twilio/recording-callback`,
        recordingStatusCallbackMethod: 'POST',
        action: `${publicBaseUrl}/api/twilio/call-status-callback`,
        method: 'POST',
      });
      dial.number(to);
    } else {
      response.say('Thank you for calling. No destination was specified.');
    }

    return response.toString();
  }
}

module.exports = new TwilioService();
