const bcrypt = require('bcryptjs');
const { pool } = require('../config/db');

async function seedDatabase() {
  const client = await pool.connect();
  try {
    console.log('Seeding demo database for Calling CRM...');
    await client.query('BEGIN');

    // 1. Teams
    const teamRes = await client.query(`
      INSERT INTO teams (name, description)
      VALUES 
        ('Enterprise Sales', 'Handling Fortune 500 & high ACV outbound telecalling'),
        ('SMB Growth', 'Fast-paced inbound demo and conversion callers')
      RETURNING id, name
    `);
    const enterpriseTeamId = teamRes.rows[0].id;
    const smbTeamId = teamRes.rows[1].id;

    // 2. Users (1 Admin, 1 Manager, 3 Agents)
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash('Password123!', salt);

    const userRes = await client.query(`
      INSERT INTO users (name, email, password_hash, role, team_id, phone, status)
      VALUES 
        ('Sarah Jenkins (Admin)', 'admin@crm.com', $1, 'admin', $2, '+15550100', 'active'),
        ('David Ross (Manager)', 'manager@crm.com', $1, 'manager', $2, '+15550101', 'active'),
        ('Alex Rivera (Agent)', 'alex@crm.com', $1, 'agent', $2, '+15550102', 'active'),
        ('Elena Gomez (Agent)', 'elena@crm.com', $1, 'agent', $3, '+15550103', 'active'),
        ('Marcus Chen (Agent)', 'marcus@crm.com', $1, 'agent', $3, '+15550104', 'active')
      RETURNING id, name, role
    `, [passwordHash, enterpriseTeamId, smbTeamId]);

    const users = userRes.rows;
    const alex = users.find(u => u.name.includes('Alex'));
    const elena = users.find(u => u.name.includes('Elena'));
    const marcus = users.find(u => u.name.includes('Marcus'));

    // 3. Leads (12 realistic sales leads across diverse sectors)
    const leadRes = await client.query(`
      INSERT INTO leads (first_name, last_name, phone, email, company, source, status, tags, assigned_to, notes)
      VALUES 
        ('Jonathan', 'Vance', '+14155552671', 'jvance@apexcloud.io', 'Apex Cloud Solutions', 'Website', 'Interested', ARRAY['SaaS', 'High Intent'], $1, 'Looking for modern VoIP CRM integration for 40 seat team.'),
        ('Claire', 'Redfield', '+12125559834', 'claire@biohealthsys.org', 'BioHealth Systems', 'LinkedIn', 'Follow-up', ARRAY['Healthcare', 'Enterprise'], $1, 'Interested in HIPAA compliance and call recording encryption.'),
        ('Devon', 'Miles', '+13125554490', 'devon@milestransport.com', 'Miles Logistics Corp', 'Cold Outreach', 'Contacted', ARRAY['Logistics'], $2, 'Needs fleet driver dispatch calling with click-to-call.'),
        ('Sophia', 'Alvarez', '+15125557788', 'sophia@fintechpulse.co', 'FinTech Pulse', 'Google Ads', 'Converted', ARRAY['Fintech', 'VIP'], $2, 'Closed 12-month annual plan. Onboarding kickoff scheduled.'),
        ('Robert', 'Sterling', '+16175553322', 'robert@sterlinglaw.com', 'Sterling & Partners Legal', 'Referral', 'New', ARRAY['Legal'], $3, 'Referred by Michael Scott. Needs call timer and billing records.'),
        ('Amara', 'Okafor', '+14045558811', 'amara@solargreen.tech', 'SolarGreen Energy', 'Website', 'Interested', ARRAY['CleanTech'], $3, 'Wants demo on power dialer queue for residential leads.'),
        ('Tariq', 'Mansoor', '+17025556633', 'tariq@skylinehospitality.com', 'Skyline Hospitality Group', 'Trade Show', 'Not Interested', ARRAY['Hospitality'], $1, 'Existing contract with legacy PBX until next year.'),
        ('Jessica', 'Huang', '+12065551928', 'jessica@nwretailgroup.com', 'Northwest Retail Brands', 'Website', 'Follow-up', ARRAY['Retail', 'Multi-location'], $2, 'Callback requested for Thursday 3 PM PST to discuss manager dashboards.'),
        ('Liam', 'Gallagher', '+13055558273', 'liam@miamicapital.fund', 'Miami Bay Capital', 'LinkedIn', 'Wrong Number', ARRAY['Private Equity'], $3, 'Receptionist informed executive left firm; need new contact.'),
        ('Kavita', 'Patel', '+16505559041', 'kavita@nexusai.labs', 'Nexus AI Robotics', 'Inbound Demo', 'New', ARRAY['AI', 'Series B'], $1, 'Signed up for live trial yesterday. High priority lead.'),
        ('Daniel', 'Kovacs', '+13035552940', 'daniel@summitpeak.co', 'Summit Peak Outdoors', 'Google Ads', 'Contacted', ARRAY['E-commerce'], $2, 'Discussing holiday peak outbound campaign dialer setup.'),
        ('Rachel', 'Green', '+12125550992', 'rachel@ralphfashion.com', 'Ralph Lauren Commercial', 'Referral', 'Interested', ARRAY['Fashion'], $3, 'Wants automated WhatsApp templates after follow-up calls.')
      RETURNING id, first_name, last_name, phone, company, status, assigned_to
    `, [alex.id, elena.id, marcus.id]);

    const leads = leadRes.rows;

    // 4. Sample Calls with recordings & dispositions
    await client.query(`
      INSERT INTO calls (lead_id, user_id, direction, status, outcome, duration_seconds, notes, recording_url, started_at)
      VALUES 
        ($1, $4, 'outbound', 'completed', 'Interested', 342, 'Prospect loved the browser WebRTC dialer and asked for a 20-seat quote.', 'https://assets.mixkit.co/active_storage/sfx/2874/2874-preview.mp3', CURRENT_TIMESTAMP - INTERVAL '3 hours'),
        ($2, $4, 'outbound', 'completed', 'Follow-up', 418, 'Discussed security requirements. Scheduled follow-up with their VP of IT.', 'https://assets.mixkit.co/active_storage/sfx/2874/2874-preview.mp3', CURRENT_TIMESTAMP - INTERVAL '5 hours'),
        ($4, $5, 'outbound', 'completed', 'Converted', 720, 'Final negotiation call. Agreed on $180/agent/month tier.', 'https://assets.mixkit.co/active_storage/sfx/2874/2874-preview.mp3', CURRENT_TIMESTAMP - INTERVAL '1 day'),
        ($3, $5, 'outbound', 'completed', 'Follow-up', 185, 'Spoke with operations director, sending WhatsApp one-pager.', NULL, CURRENT_TIMESTAMP - INTERVAL '2 days'),
        ($7, $4, 'outbound', 'completed', 'Not Interested', 110, 'Locked in long-term contract with current telecom provider.', NULL, CURRENT_TIMESTAMP - INTERVAL '1 day'),
        ($9, $6, 'outbound', 'completed', 'Wrong Number', 45, 'Wrong extension on file.', NULL, CURRENT_TIMESTAMP - INTERVAL '4 hours')
    `, [leads[0].id, leads[1].id, leads[3].id, alex.id, elena.id, marcus.id]);

    // 5. Follow-ups (including today's callbacks)
    await client.query(`
      INSERT INTO follow_ups (lead_id, user_id, scheduled_at, status, notes, priority)
      VALUES 
        ($1, $4, CURRENT_TIMESTAMP + INTERVAL '2 hours', 'pending', 'Present custom proposal and Twilio trunking pricing', 'high'),
        ($2, $4, CURRENT_TIMESTAMP + INTERVAL '5 hours', 'pending', 'Security review call with compliance officer', 'high'),
        ($8, $5, CURRENT_TIMESTAMP + INTERVAL '3 hours', 'pending', 'Walkthrough of manager leaderboard and power dialer queue', 'medium'),
        ($5, $6, CURRENT_TIMESTAMP - INTERVAL '2 hours', 'overdue', 'Urgent callback: Robert requested contract pricing', 'high'),
        ($10, $4, CURRENT_TIMESTAMP + INTERVAL '1 day', 'pending', 'Inbound demo trial check-in', 'medium')
    `, [leads[0].id, leads[1].id, leads[7].id, leads[4].id, leads[9].id, alex.id, elena.id, marcus.id]);

    // 6. Call Scripts (Editable in app)
    await client.query(`
      INSERT INTO call_scripts (title, category, content)
      VALUES 
        ('Cold Outbound - SaaS Discovery', 'Outbound Sales', 
         'INTRO: "Hi {name}, this is {agent} calling from Apex CRM. I noticed you oversee growth at {company}. Do you have 60 seconds?"

HOOK: "We help telecalling teams double their connect rates with in-browser WebRTC calling and zero-lag disposition logging."

QUALIFYING QUESTIONS:
1. How many daily outbound calls is your team making right now?
2. Are agents losing 10-15 minutes per hour manually dialing numbers and switching between apps?
3. Would an automated power-dialer queue with automatic call logging speed up your pipeline?'),
        ('Demo Booking Follow-up', 'Inbound Follow-up',
         'INTRO: "Hi {name}, {agent} here following up on your demo request for {company}."

AGENDA: "I wanted to make sure we tailor the session to your exact telephony setup. Are you currently using Twilio or traditional SIP trunks?"

CALL TO ACTION: "Let us lock in a 20-minute live screen share for either tomorrow at 2 PM or Thursday at 11 AM. Which one works better for you?"'),
        ('Objection Handling: We already have a phone system', 'Objection Handling',
         'OBJECTION: "We are already using another phone provider."

RESPONSE: "Completely understand! Most of our customers were using legacy softphones before switching. The difference with our Calling CRM is that agents never have to copy-paste numbers or leave their lead screen—everything happens right in the browser with one-click dispositions and instant manager dashboards. Are you open to comparing connect rates side-by-side?"')
    `);

    // 7. Message Templates (Email & WhatsApp)
    await client.query(`
      INSERT INTO templates (title, channel, subject, body, created_by)
      VALUES 
        ('Post-Call Follow-up (Email)', 'email', 'Great speaking with you, {name} - Calling CRM Details',
         'Hi {name},

Thank you for taking my call today regarding {company}. As promised, here is the summary of what we discussed.

Our Calling CRM provides in-browser WebRTC dialing, automated dispositions, call recordings, and team performance tracking.

Let me know if tomorrow at 3:00 PM works for our quick 15-minute walkthrough!

Best regards,
{agent}', $1),
        ('Quick Intro & Proposal (WhatsApp)', 'whatsapp', NULL,
         'Hello {name}! 👋 It was a pleasure speaking with you regarding {company}. Here is the link to review our Calling CRM walkthrough and Twilio setup guide: https://callingcrm.demo/overview. Feel free to reply here directly if you have any questions! - {agent}', $1),
        ('Meeting Reminder (WhatsApp)', 'whatsapp', NULL,
         'Hi {name}! Friendly reminder about our scheduled call today at {time}. Looking forward to connecting with the {company} team! - {agent}', $1)
    `, [users[0].id]);

    await client.query('COMMIT');
    console.log('Seeding completed successfully!');
    console.log('Demo Credentials:');
    console.log('  Admin:   admin@crm.com   / Password123!');
    console.log('  Manager: manager@crm.com / Password123!');
    console.log('  Agent 1: alex@crm.com    / Password123!');
    console.log('  Agent 2: elena@crm.com   / Password123!');
    console.log('  Agent 3: marcus@crm.com  / Password123!');
    process.exit(0);
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Seeding error:', err);
    process.exit(1);
  } finally {
    client.release();
  }
}

if (require.main === module) {
  seedDatabase();
}

module.exports = { seedDatabase };
