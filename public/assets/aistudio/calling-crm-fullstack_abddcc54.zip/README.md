# KRK KRYPTA — Full-Stack Multi-Tenant Calling CRM (By Team KRK: KT, RDX, KD)

A production-ready Calling CRM web application engineered for sales, outbound telecalling, and customer success teams. Features in-browser WebRTC voice calling via Twilio Voice API, automated call disposition popups, power dialer queueing, lead pipeline management with duplicate detection, follow-up scheduling with overdue alerts, manager leaderboards, and interactive performance dashboards.

---

## 📑 Table of Contents
1. [Key Features](#key-features)
2. [Tech Stack & Architecture](#tech-stack--architecture)
3. [Folder Structure](#folder-structure)
4. [Prerequisites & Environment Variables](#prerequisites--environment-variables)
5. [Database Setup & Migrations](#database-setup--migrations)
6. [Twilio Voice Integration Setup Guide](#twilio-voice-integration-setup-guide)
7. [Running the Application](#running-the-application)
8. [Role-Based Access Control (RBAC)](#role-based-access-control-rbac)
9. [API Endpoints Reference](#api-endpoints-reference)
10. [Deployment Guide](#deployment-guide)

---

## 🚀 Key Features

### 1. Lead Management
- **Manual & Bulk CSV Import**: Add individual leads or bulk import hundreds via CSV/Excel with automatic duplicate detection by phone number.
- **Lead Fields**: Name, phone, email, company, source, status, tags, assigned agent, custom fields, and notes.
- **Lead Statuses**: `New`, `Contacted`, `Interested`, `Follow-up`, `Not Interested`, `Converted`, `Wrong Number`.
- **Search & Multi-Filter**: Filter by status, assigned agent, date range, and lead source; sort by any column.
- **Lead Detail & Timeline**: Chronological activity timeline combining calls, notes, scheduled follow-ups, and audit logs.

### 2. High-Performance Calling
- **In-Browser WebRTC Dialer**: Dial directly through the browser with Twilio Voice SDK. Supports live call timer, mute, hold, and hang-up controls.
- **Audio DTMF Tone Generator**: Built-in Web Audio API generates realistic telephone keypad tones (0-9, *, #) for interactive dial pads.
- **Mandatory Disposition Modal**: Agents cannot bypass call logging. Immediately upon hang-up, the system prompts for outcome, notes, and follow-up callback date/time.
- **Auto-Log Call Metrics**: Automatically records call duration in seconds, agent ID, started/ended timestamps, and Twilio Call SID.
- **Call Recording & Playback**: In-browser audio player for reviewing recorded calls.
- **Power Dialer Mode**: Auto-loads and queues the next lead in the list to maximize agent talk time.
- **Click-to-Call Fallback**: Fallback `tel:` URI for native OS or softphone dialers.

### 3. Follow-ups & Reminders
- **Callback Scheduling**: Date, time, priority (`low`, `medium`, `high`), and notes.
- **"Today's Follow-ups" Widget**: Dedicated dashboard view highlighting callbacks due today and alerting on overdue tasks.
- **Browser Notifications & In-App Alerts**: Proactive alert badges for pending and overdue callbacks.

### 4. Dashboards & Analytics
- **Agent Dashboard**: Calls made today, talk time in minutes, conversions, and follow-ups due.
- **Manager / Admin Dashboard**:
  - Live team leaderboard ranked by conversions and talk time.
  - Conversion rate percentages with date range filtering (`Today`, `7 Days`, `30 Days`, `All Time`).
  - Call outcome distribution pie chart (`Interested`, `Follow-up`, `Converted`, etc.).
  - Lead source performance bar chart (Website, LinkedIn, Cold Outreach, Google Ads, Referrals).

### 5. Automated Lead Assignment
- **Manual Assignment & Bulk Reassignment**: Manager can reassign batches of leads in one click.
- **Round-Robin Auto-Assign**: Distributes incoming leads evenly across all active agents.
- **Workload-Balanced Auto-Assign**: Automatically routes leads to the agent currently handling the fewest active leads.

### 6. Productivity & Collateral
- **Call Scripts Drawer**: Dynamic scripts displayed right beside the dialer with automatic variable replacement (`{name}`, `{company}`, `{agent}`).
- **One-Click Email & WhatsApp Templates**: Ready-to-send messages pre-populated with lead data (`mailto:` and `https://wa.me/` deep links).
- **CSV Data Export**: One-click export for leads and call logs.
- **Dark Mode**: Fully supported light/dark theme switch.

---

## 🛠 Tech Stack & Architecture

- **Frontend**: React 18, Tailwind CSS, Lucide Icons, Chart.js, Vite.
- **Backend**: Node.js, Express.js (REST API, Rate Limiting, Helmet Security).
- **Database**: PostgreSQL (with connection pooling via `pg`).
- **Authentication**: JWT (JSON Web Tokens) with `bcryptjs` password hashing and role-based middleware.
- **Telephony**: Twilio Voice SDK (WebRTC in-browser audio), TwiML Webhook handlers, Call & Recording status callbacks.

```
+-------------------------------------------------------------------------+
|                              FRONTEND                                   |
|  React 18 + Tailwind CSS + Lucide Icons + Chart.js + Twilio Voice SDK   |
+--------------------+--------------------------------+-------------------+
                     | HTTP / REST (JWT Auth)         | WebRTC Audio
                     v                                v
+--------------------+--------------------------------+-------------------+
|                              BACKEND                                    |
|      Node.js + Express REST API (Controllers, RBAC, Services, RateLimit)|
+--------------------+--------------------------------+-------------------+
                     | pg connection pool             | Twilio Voice API
                     v                                v
+--------------------+--------------+   +-------------+-------------------+
|         DATABASE (PostgreSQL)     |   |          TWILIO CLOUD           |
| Users, Leads, Calls, Follow-ups,  |   | Voice Tokens, TwiML App,        |
| Scripts, Templates, Activity Logs |   | Call Recordings, PSTN Gateway   |
+-----------------------------------+   +---------------------------------+
```

---

## 📁 Folder Structure

```
calling-crm/
├── backend/
│   ├── config/
│   │   └── db.js                 # PostgreSQL connection pool and query helper
│   ├── controllers/
│   │   ├── authController.js     # Login, profile, and JWT issue
│   │   ├── callController.js     # Initiate call, mandatory disposition, CSV export
│   │   ├── dashboardController.js# Agent KPIs, Manager leaderboard & charts
│   │   ├── followUpController.js # Today's follow-ups, overdue alerts
│   │   ├── leadController.js     # CRUD, CSV bulk import, duplicate phone check
│   │   ├── scriptController.js   # Editable call scripts for dialer widget
│   │   ├── teamController.js     # User & agent team management
│   │   └── templateController.js # Email & WhatsApp templates
│   ├── middleware/
│   │   ├── auth.js               # JWT verification & user injection
│   │   ├── errorHandler.js       # Centralized error handler
│   │   ├── rateLimiter.js        # Express rate limiting
│   │   └── rbac.js               # Role-based access control (admin, manager, agent)
│   ├── models/
│   │   ├── migrate.js            # Database migration runner script
│   │   └── schema.sql            # PostgreSQL DDL schema definition
│   ├── routes/
│   │   ├── authRoutes.js         # /api/auth
│   │   ├── callRoutes.js         # /api/calls
│   │   ├── dashboardRoutes.js    # /api/dashboard
│   │   ├── followUpRoutes.js     # /api/follow-ups
│   │   ├── leadRoutes.js         # /api/leads
│   │   ├── scriptRoutes.js       # /api/scripts
│   │   ├── teamRoutes.js         # /api/team
│   │   ├── templateRoutes.js     # /api/templates
│   │   └── twilioRoutes.js       # /api/twilio (WebRTC token & TwiML webhooks)
│   ├── seeds/
│   │   └── seed.js               # Populates demo data (leads, agents, calls, scripts)
│   ├── services/
│   │   ├── leadAssignmentService.js # Round-robin and workload auto-assignment
│   │   └── twilioService.js      # Voice grant tokens & outbound TwiML generation
│   ├── .env.example              # Sample backend environment configuration
│   ├── package.json              # Backend dependencies & npm scripts
│   └── server.js                 # Express application bootstrap
│
├── frontend/
│   ├── public/
│   ├── src/
│   │   ├── components/
│   │   │   ├── CallScriptWidget.jsx    # Side-by-side script with variable substitution
│   │   │   ├── DispositionModal.jsx    # Mandatory call outcome modal
│   │   │   ├── InBrowserDialer.jsx     # WebRTC phone pad & controls
│   │   │   ├── MessageTemplateModal.jsx# WhatsApp & Email template sender
│   │   │   ├── Navbar.jsx              # Header, theme toggle & user profile
│   │   │   └── Sidebar.jsx             # Main navigation & WebRTC badge
│   │   ├── context/
│   │   │   ├── AuthContext.jsx         # User login state & role management
│   │   │   └── CallContext.jsx         # Global calling state, timers, & queue
│   │   ├── pages/
│   │   │   ├── CallLogsPage.jsx        # Audio recording playback & call history
│   │   │   ├── DashboardPage.jsx       # KPIs, charts & follow-ups widget
│   │   │   ├── FollowUpsPage.jsx       # Callbacks list & overdue tracker
│   │   │   ├── LeadDetailPage.jsx      # Full activity timeline & notes
│   │   │   ├── LeadsListPage.jsx       # Table, multi-filter, search, CSV import
│   │   │   ├── LoginPage.jsx           # Role-based login screen
│   │   │   ├── SettingsPage.jsx        # Twilio credentials & audio tester
│   │   │   └── TeamPage.jsx            # Agent workload & user invites
│   │   ├── services/
│   │   │   ├── api.js                  # Axios HTTP client with interceptors
│   │   │   └── twilioClient.js         # Twilio Voice Device WebRTC integration
│   │   ├── App.jsx                     # Router & route definitions
│   │   └── index.jsx                   # React DOM root entry
│   ├── package.json                    # Frontend dependencies
│   ├── tailwind.config.js              # Tailwind styling config
│   └── vite.config.js                  # Vite bundler config
│
└── README.md                           # Comprehensive documentation (this file)
```

---

## ⚙️ Prerequisites & Environment Variables

### 1. Prerequisites
- **Node.js**: v18.0.0 or higher
- **npm**: v9.0.0 or higher
- **PostgreSQL**: v14.0 or higher (or cloud PostgreSQL like Supabase, Neon, or AWS RDS)
- *(Optional for real calling)*: Active **Twilio Account**

### 2. Backend Environment Variables (`backend/.env`)
Create `backend/.env` using the provided `.env.example`:

```bash
cp backend/.env.example backend/.env
```

Edit the file with your values:
```env
PORT=5000
NODE_ENV=development
CLIENT_URL=http://localhost:3000

# PostgreSQL Connection
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/calling_crm

# JWT Configuration
JWT_SECRET=replace_with_a_secure_random_string_min_32_chars
JWT_EXPIRES_IN=7d

# Twilio Voice Telephony Configuration
TWILIO_ACCOUNT_SID=ACXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
TWILIO_AUTH_TOKEN=your_twilio_auth_token_here
TWILIO_API_KEY_SID=SKXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
TWILIO_API_KEY_SECRET=your_twilio_api_key_secret_here
TWILIO_TWIML_APP_SID=APXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
TWILIO_CALLER_ID=+18005550199

# Public Webhook URL (use ngrok for local development)
PUBLIC_URL=https://your-subdomain.ngrok-free.app
```

---

## 🗄 Database Setup & Migrations

### 1. Create PostgreSQL Database
```bash
createdb -U postgres calling_crm
```

### 2. Run Database Migrations
Run the migration script to create all required tables, constraints, and indexes:
```bash
cd backend
npm run db:migrate
```

### 3. Seed Demo Data
Populate the database with demo users, 12 realistic sales leads, call history, follow-up callbacks, scripts, and message templates:
```bash
npm run seed
```

#### Demo User Accounts:
| Role | Email | Password | Permissions |
| :--- | :--- | :--- | :--- |
| **Admin** | `admin@crm.com` | `Password123!` | Full access: team users, Twilio settings, scripts, all leads |
| **Manager** | `manager@crm.com` | `Password123!` | Team leaderboard, reassign leads, review recordings, reports |
| **Agent 1** | `alex@crm.com` | `Password123!` | Sees assigned leads, WebRTC dialer, logs dispositions |
| **Agent 2** | `elena@crm.com` | `Password123!` | Sees assigned leads, WebRTC dialer, logs dispositions |
| **Agent 3** | `marcus@crm.com` | `Password123!` | Sees assigned leads, WebRTC dialer, logs dispositions |

---

## 📞 Twilio Voice Integration Setup Guide

Follow these steps to enable real in-browser phone calling:

### Step 1: Obtain a Twilio Phone Number
1. Log into your [Twilio Console](https://console.twilio.com/).
2. Navigate to **Phone Numbers** > **Manage** > **Active numbers** (or click **Buy a number**).
3. Ensure the number supports **Voice**.
4. Copy the number (e.g. `+18005550199`) and set it as `TWILIO_CALLER_ID` in `backend/.env`.

### Step 2: Create a TwiML App
1. In Twilio Console, go to **Voice** > **Manage** > **TwiML Apps**.
2. Click **Create new TwiML App**.
3. **Friendly Name**: `Calling CRM Browser Dialer`.
4. **Voice Configuration**:
   - Request URL: `https://<YOUR_PUBLIC_URL>/api/twilio/voice-twiml`
   - HTTP Method: `POST`
5. Save the TwiML App.
6. Copy the **Application SID** (starts with `AP...`) and set it as `TWILIO_TWIML_APP_SID` in `backend/.env`.

### Step 3: Create an API Key & Secret
1. Go to **Account** > **API keys & tokens**.
2. Click **Create API key**.
3. **Friendly Name**: `Calling CRM WebRTC Key`.
4. Key type: **Standard**.
5. Copy the **SID** (starts with `SK...`) into `TWILIO_API_KEY_SID`.
6. Copy the **Secret** into `TWILIO_API_KEY_SECRET`.

### Step 4: Expose Local Backend with ngrok (for development)
Since Twilio needs to reach your webhook to fetch TwiML when an agent dials out:
```bash
ngrok http 5000
```
Copy the forwarding HTTPS URL (e.g., `https://abc123.ngrok-free.app`) and update:
1. `PUBLIC_URL` in `backend/.env`.
2. The Voice Request URL in your Twilio TwiML App.

---

## 💻 Running the Application

### 1. Start Backend Server
```bash
cd backend
npm install
npm run dev
```
Backend will start on `http://localhost:5000`.

### 2. Start Frontend App
```bash
cd frontend
npm install
npm run dev
```
Frontend will be available at `http://localhost:3000`.

---

## 🔒 Role-Based Access Control (RBAC)

| Feature | Admin | Manager | Agent |
| :--- | :---: | :---: | :---: |
| View Assigned Leads | ✅ | ✅ | ✅ |
| View All Team Leads | ✅ | ✅ | ❌ |
| In-Browser WebRTC Dialer | ✅ | ✅ | ✅ |
| Log Call Dispositions | ✅ | ✅ | ✅ |
| Schedule Follow-ups | ✅ | ✅ | ✅ |
| Today's Follow-up Widget | ✅ | ✅ | ✅ |
| Lead Reassignment | ✅ | ✅ | ❌ |
| Round-Robin Auto-Assign | ✅ | ✅ | ❌ |
| Team Leaderboard & KPIs | ✅ | ✅ | ❌ (Own only) |
| Review Call Recordings | ✅ | ✅ | ❌ |
| Export CSVs | ✅ | ✅ | ❌ |
| Create / Edit Call Scripts | ✅ | ❌ | ❌ |
| User / Team Management | ✅ | ❌ | ❌ |
| Twilio Telephony Settings | ✅ | ❌ | ❌ |

---

## 📡 API Endpoints Reference

### Authentication
- `POST /api/auth/login` — Authenticate and receive JWT token.
- `GET /api/auth/me` — Get current user profile and role.

### Leads
- `GET /api/leads` — Query leads with filtering (`status`, `source`, `assignedTo`, `search`), sorting, and pagination.
- `GET /api/leads/:id` — Get single lead with full activity timeline (calls, notes, follow-ups).
- `POST /api/leads` — Create new lead (with duplicate phone validation).
- `PUT /api/leads/:id` — Update lead details.
- `POST /api/leads/:id/notes` — Add internal note to lead.
- `POST /api/leads/bulk-import` — Bulk import leads from parsed CSV with duplicate handling.
- `GET /api/leads/export` — Download leads as CSV.
- `POST /api/leads/auto-assign/round-robin` — Distribute selected leads evenly among agents.
- `POST /api/leads/auto-assign/workload` — Route leads to agents with fewest active leads.

### Calling & Dispositions
- `GET /api/calls` — Call history and recording links.
- `POST /api/calls/initiate` — Register new call session.
- `POST /api/calls/disposition` — Mandatory disposition save (outcome, notes, timer, follow-up).
- `GET /api/calls/export` — Download call logs as CSV.

### Twilio Telephony
- `GET /api/twilio/token` — Generate Twilio Voice JWT token for WebRTC browser client.
- `POST /api/twilio/voice-twiml` — Outbound call webhook returning TwiML XML.
- `POST /api/twilio/call-status-callback` — Twilio webhook for call duration and status.
- `POST /api/twilio/recording-callback` — Webhook for recording audio URLs.

### Follow-ups & Reminders
- `GET /api/follow-ups/today` — List callbacks scheduled for today and overdue reminders.
- `POST /api/follow-ups` — Schedule a callback.
- `PUT /api/follow-ups/:id` — Mark completed or reschedule.

### Dashboards & Reports
- `GET /api/dashboard/stats?range=today|7d|30d|all` — Return agent KPIs or manager team stats.

### Scripts & Templates
- `GET /api/scripts` — List active call scripts.
- `POST /api/scripts` — Create call script (Admin).
- `GET /api/templates` — List WhatsApp and Email message templates.
- `POST /api/templates` — Create message template.

---

## 🚀 Deployment Guide

### Option 1: Docker Compose
Run the entire stack (PostgreSQL + Node.js API + React frontend) with a single command:
```bash
docker-compose up --build
```

### Option 2: Cloud PaaS (Render / Railway / Heroku)
1. Provision a managed **PostgreSQL database**.
2. Deploy the backend as a Node.js web service with environment variables set from `backend/.env.example`.
3. Set build command: `npm install && npm run db:migrate && npm run seed`.
4. Deploy the frontend to Vercel, Netlify, or Render Static Sites with `VITE_API_URL` pointing to the backend.
