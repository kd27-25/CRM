import { Device } from '@twilio/voice-sdk';
import api from './api';

class TwilioVoiceClient {
  constructor() {
    this.device = null;
    this.activeCall = null;
    this.token = null;
    this.isReady = false;
  }

  async initialize() {
    try {
      const res = await api.get('/twilio/token');
      if (!res.data || !res.data.token) {
        console.warn('No Twilio token received');
        return false;
      }

      this.token = res.data.token;
      if (res.data.isMock) {
        console.log('Using simulated Twilio voice device');
        this.isReady = true;
        return true;
      }

      this.device = new Device(this.token, {
        codecPreferences: ['opus', 'pcmu'],
        fakeLocalDTMF: true,
        enableRingingState: true,
      });

      this.device.on('ready', () => {
        this.isReady = true;
        console.log('Twilio Device is ready for WebRTC calls');
      });

      this.device.on('error', (error) => {
        console.error('Twilio Device error:', error);
      });

      await this.device.register();
      return true;
    } catch (err) {
      console.error('Failed to initialize Twilio Device:', err);
      return false;
    }
  }

  async makeCall(phoneNumber) {
    if (!this.device) {
      console.log('Simulating outbound call to:', phoneNumber);
      return { status: 'simulated', to: phoneNumber };
    }

    const params = { To: phoneNumber };
    const call = await this.device.connect({ params });
    this.activeCall = call;
    return call;
  }

  hangUp() {
    if (this.activeCall) {
      this.activeCall.disconnect();
      this.activeCall = null;
    } else if (this.device) {
      this.device.disconnectAll();
    }
  }

  mute(shouldMute) {
    if (this.activeCall) {
      this.activeCall.mute(shouldMute);
    }
  }
}

export default new TwilioVoiceClient();
