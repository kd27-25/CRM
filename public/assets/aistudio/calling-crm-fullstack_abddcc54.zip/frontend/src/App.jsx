import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { CallProvider } from './context/CallContext';

import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import DispositionModal from './components/DispositionModal';

function AppContent() {
  const { isAuthenticated, loading } = useAuth();
  const [darkMode, setDarkMode] = useState(false);
  const [dialerOpen, setDialerOpen] = useState(false);

  if (loading) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-slate-100 dark:bg-slate-950">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className={darkMode ? 'dark' : ''}>
      <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors">
        <Navbar darkMode={darkMode} setDarkMode={setDarkMode} onOpenDialer={() => setDialerOpen(true)} />
        <div className="flex flex-1 overflow-hidden">
          <Sidebar />
          <main className="flex-1 overflow-y-auto p-6">
            {/* Main view container */}
            <div className="max-w-7xl mx-auto space-y-6">
              <div className="p-8 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
                <h2 className="text-2xl font-bold">Calling CRM Workspace Loaded</h2>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                  Ready for telecalling agents and managers.
                </p>
              </div>
            </div>
          </main>
        </div>
        <DispositionModal />
      </div>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <CallProvider>
          <AppContent />
        </CallProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
