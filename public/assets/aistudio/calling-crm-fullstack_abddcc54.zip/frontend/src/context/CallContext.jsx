import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import twilioClient from '../services/twilioClient';
import api from '../services/api';

const CallContext = createContext();

export function CallProvider({ children }) {
  const [callState, setCallState] = useState('idle'); // 'idle' | 'calling' | 'connected' | 'disposition'
  const [activeLead, setActiveLead] = useState(null);
  const [currentCallId, setCurrentCallId] = useState(null);
  const [timerSeconds, setTimerSeconds] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isOnHold, setIsOnHold] = useState(false);
  const [powerDialerActive, setPowerDialerActive] = useState(false);
  const [powerDialerQueue, setPowerDialerQueue] = useState([]);
  const timerRef = useRef(null);

  useEffect(() => {
    if (callState === 'connected') {
      timerRef.current = setInterval(() => {
        setTimerSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      clearInterval(timerRef.current);
    }
    return () => clearInterval(timerRef.current);
  }, [callState]);

  const startCall = async (lead) => {
    try {
      setActiveLead(lead);
      setCallState('calling');
      setTimerSeconds(0);
      setIsMuted(false);
      setIsOnHold(false);

      // Create call record in backend
      const res = await api.post('/calls/initiate', { leadId: lead.id, direction: 'outbound' });
      setCurrentCallId(res.data.call.id);

      // Connect via Twilio Voice WebRTC
      await twilioClient.makeCall(lead.phone);

      // Transition to connected state
      setTimeout(() => {
        setCallState('connected');
      }, 1200);
    } catch (err) {
      console.error('Call initiation error:', err);
      setCallState('idle');
    }
  };

  const hangUp = () => {
    twilioClient.hangUp();
    setCallState('disposition'); // Mandatory disposition state
  };

  const toggleMute = () => {
    const next = !isMuted;
    twilioClient.mute(next);
    setIsMuted(next);
  };

  const toggleHold = () => {
    setIsOnHold((prev) => !prev);
  };

  const submitDisposition = async (dispositionData) => {
    try {
      await api.post('/calls/disposition', {
        callId: currentCallId,
        durationSeconds: timerSeconds,
        ...dispositionData,
      });

      setCallState('idle');
      setActiveLead(null);
      setCurrentCallId(null);
      setTimerSeconds(0);

      // If power dialer is active, load next lead
      if (powerDialerActive && powerDialerQueue.length > 0) {
        const nextLead = powerDialerQueue[0];
        setPowerDialerQueue((prev) => prev.slice(1));
        setTimeout(() => {
          startCall(nextLead);
        }, 1500);
      }
    } catch (err) {
      console.error('Failed to submit disposition:', err);
    }
  };

  return (
    <CallContext.Provider
      value={{
        callState,
        activeLead,
        currentCallId,
        timerSeconds,
        isMuted,
        isOnHold,
        powerDialerActive,
        powerDialerQueue,
        setPowerDialerActive,
        setPowerDialerQueue,
        startCall,
        hangUp,
        toggleMute,
        toggleHold,
        submitDisposition,
      }}
    >
      {children}
    </CallContext.Provider>
  );
}

export const useCall = () => useContext(CallContext);
