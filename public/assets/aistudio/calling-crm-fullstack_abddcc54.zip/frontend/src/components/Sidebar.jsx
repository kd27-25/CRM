import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { 
  LayoutDashboard, 
  Users, 
  PhoneForwarded, 
  CalendarClock, 
  History, 
  ShieldCheck, 
  FileText, 
  Settings 
} from 'lucide-react';

export default function Sidebar() {
  const { user } = useAuth();
  const isAdminOrManager = user?.role === 'admin' || user?.role === 'manager';

  const navItems = [
    { name: 'Dashboard', path: '/', icon: LayoutDashboard },
    { name: 'Leads Pipeline', path: '/leads', icon: Users },
    { name: 'Dialer Screen', path: '/dialer', icon: PhoneForwarded },
    { name: "Today's Follow-ups", path: '/follow-ups', icon: CalendarClock },
    { name: 'Call Logs & Audio', path: '/call-logs', icon: History },
    ...(isAdminOrManager ? [{ name: 'Team & Agents', path: '/team', icon: ShieldCheck }] : []),
    { name: 'Call Scripts', path: '/scripts', icon: FileText },
    { name: 'Settings & Twilio', path: '/settings', icon: Settings },
  ];

  return (
    <aside className="w-64 bg-slate-50 dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col justify-between p-4 shrink-0 transition-colors">
      <nav className="space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center space-x-3 px-3 py-2.5 rounded-lg text-sm font-medium transition ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/30'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white'
                }`
              }
            >
              <Icon className="w-4 h-4" />
              <span>{item.name}</span>
            </NavLink>
          );
        })}
      </nav>

      {/* Twilio WebRTC Status Indicator badge */}
      <div className="p-3 bg-white dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-700/60 shadow-sm">
        <div className="flex items-center space-x-2">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
          <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">Twilio WebRTC Online</span>
        </div>
        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
          In-browser voice audio engine active
        </p>
      </div>
    </aside>
  );
}
