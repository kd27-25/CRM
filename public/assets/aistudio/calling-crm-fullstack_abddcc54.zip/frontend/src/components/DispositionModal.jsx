import React, { useState } from 'react';
import { useCall } from '../context/CallContext';
import { CheckCircle2, Clock, Calendar, AlertCircle } from 'lucide-react';

const OUTCOMES = [
  'Interested',
  'Follow-up',
  'Converted',
  'Call Back Later',
  'Voicemail',
  'Not Interested',
  'Wrong Number',
  'No Answer',
];

export default function DispositionModal() {
  const { callState, activeLead, timerSeconds, submitDisposition } = useCall();
  const [outcome, setOutcome] = useState('');
  const [notes, setNotes] = useState('');
  const [followUpDate, setFollowUpDate] = useState('');
  const [followUpTime, setFollowUpTime] = useState('');
  const [error, setError] = useState('');

  if (callState !== 'disposition') return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!outcome) {
      setError('Please select a mandatory call outcome.');
      return;
    }

    if (outcome === 'Follow-up' && (!followUpDate || !followUpTime)) {
      setError('Please specify the date and time for the follow-up callback.');
      return;
    }

    submitDisposition({
      outcome,
      notes,
      nextFollowUpDate: followUpDate || null,
      nextFollowUpTime: followUpTime || null,
    });
  };

  const formatDuration = (sec) => {
    const mins = Math.floor(sec / 60);
    const s = sec % 60;
    return `${mins}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full border border-slate-200 dark:border-slate-800 shadow-2xl p-6">
        <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
          <div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-500" />
              Call Disposition Logging
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Lead: {activeLead?.first_name} {activeLead?.last_name} ({activeLead?.phone})
            </p>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1 bg-slate-100 dark:bg-slate-800 rounded-full text-xs font-semibold text-slate-700 dark:text-slate-300">
            <Clock className="w-3.5 h-3.5 text-blue-500" />
            <span>Duration: {formatDuration(timerSeconds)}</span>
          </div>
        </div>

        {error && (
          <div className="mt-4 p-3 rounded-lg bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2">
              Call Outcome <span className="text-rose-500">*</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              {OUTCOMES.map((item) => (
                <button
                  type="button"
                  key={item}
                  onClick={() => {
                    setOutcome(item);
                    setError('');
                  }}
                  className={`py-2 px-3 text-xs font-medium rounded-lg border text-left transition ${
                    outcome === item
                      ? 'border-blue-600 bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 font-semibold ring-1 ring-blue-600'
                      : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                  }`}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>

          {/* Follow-up date / time picker */}
          {(outcome === 'Follow-up' || outcome === 'Call Back Later') && (
            <div className="p-3 bg-blue-50/50 dark:bg-blue-950/20 rounded-xl border border-blue-200 dark:border-blue-900/50 space-y-2">
              <span className="text-xs font-semibold text-blue-700 dark:text-blue-300 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5" /> Schedule Callback
              </span>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="date"
                  value={followUpDate}
                  onChange={(e) => setFollowUpDate(e.target.value)}
                  className="w-full text-xs p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200"
                />
                <input
                  type="time"
                  value={followUpTime}
                  onChange={(e) => setFollowUpTime(e.target.value)}
                  className="w-full text-xs p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
              Call Notes & Key Takeaways
            </label>
            <textarea
              rows="3"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Summarize customer feedback, objections, or deal size..."
              className="w-full p-2.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          <button
            type="submit"
            className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-bold shadow-lg shadow-blue-500/20 transition"
          >
            Save Disposition & Complete Call
          </button>
        </form>
      </div>
    </div>
  );
}
