import React from 'react';
import { useAuth } from '../context/AuthContext';
import { PhoneCall, Bell, Moon, Sun, User, LogOut } from 'lucide-react';

export default function Navbar({ darkMode, setDarkMode, onOpenDialer }) {
  const { user, logout } = useAuth();

  return (
    <header className="h-16 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-6 flex items-center justify-between sticky top-0 z-30 transition-colors">
      <div className="flex items-center space-x-3">
        <div className="w-9 h-9 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold shadow-md shadow-blue-500/20">
          <PhoneCall className="w-5 h-5" />
        </div>
        <div>
          <h1 className="text-lg font-bold text-slate-900 dark:text-white tracking-tight leading-none">
            CallFlow <span className="text-blue-600 font-semibold text-sm">CRM</span>
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">Twilio Telecalling Suite</p>
        </div>
      </div>

      <div className="flex items-center space-x-4">
        {/* Quick in-browser dialer open button */}
        <button
          onClick={onOpenDialer}
          className="flex items-center space-x-2 px-3 py-1.5 bg-blue-50 dark:bg-blue-950/50 hover:bg-blue-100 text-blue-600 dark:text-blue-400 text-xs font-semibold rounded-lg border border-blue-200 dark:border-blue-800 transition"
        >
          <PhoneCall className="w-3.5 h-3.5" />
          <span>Quick Dialer</span>
        </button>

        {/* Dark mode toggle */}
        <button
          onClick={() => setDarkMode(!darkMode)}
          className="p-2 rounded-lg text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          title="Toggle Dark Mode"
        >
          {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
        </button>

        {/* User profile dropdown & role indicator */}
        <div className="flex items-center space-x-3 pl-2 border-l border-slate-200 dark:border-slate-800">
          <div className="text-right hidden sm:block">
            <p className="text-xs font-semibold text-slate-900 dark:text-slate-100">{user?.name || 'Agent'}</p>
            <span className="inline-block text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300">
              {user?.role || 'agent'}
            </span>
          </div>
          <button
            onClick={logout}
            className="p-2 rounded-lg text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition"
            title="Log Out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
}
